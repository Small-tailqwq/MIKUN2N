// Created by hack fake autoconf for windows
// not actually a config header
