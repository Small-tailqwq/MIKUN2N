CONFIG_HOST=x86_64-w64-mingw32
CONFIG_HOST_OS=mingw32
CONFIG_PREFIX=/usr/local

CC=gcc
AR=ar
WINDRES=windres

CFLAGS+= -std=gnu17 -ffile-prefix-map=C:/build/mikun2n/native/workdir/MikuN2N/artifacts/0.5.8-2/native=/usr/src/mikun2n/n3n -g -O2
LDFLAGS+=
LDLIBS_EXTRA+=-lnetapi32 -lws2_32 -liphlpapi
