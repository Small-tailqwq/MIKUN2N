CONFIG_HOST=x86_64-w64-mingw32
CONFIG_HOST_OS=mingw32
CONFIG_PREFIX=/usr/local

CC=gcc
AR=ar
WINDRES=windres

CFLAGS+=-g -O2 -std=gnu17 -ffile-prefix-map=$(CURDIR)=/usr/src/mikun2n/n3n
LDFLAGS+=
LDLIBS_EXTRA+=-lnetapi32 -lws2_32 -liphlpapi
